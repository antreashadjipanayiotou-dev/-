import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

/*
  GitHub Pages is a static host. This version therefore stores uploaded MP3s
  in the browser's IndexedDB. The files can be selected directly from iPhone/
  Android Files/Downloads and remain available on that device/browser.

  IMPORTANT: this PIN is NOT server-side security. For a truly private admin
  account with uploads shared across devices, connect a backend such as
  Supabase/Firebase. See README.md.
*/
const ADMIN_PIN = "2580";
const DB_NAME = "andreas-creator-app";
const STORE = "songs";

const tabs = [
  { id: "demos", label: "Demos", icon: "headphones" },
  { id: "lyrics", label: "Στίχοι", icon: "edit" },
  { id: "releases", label: "Κυκλοφορίες", icon: "music" },
  { id: "bio", label: "Βιογραφικό", icon: "person" },
];

function Icon({ name, size = 28 }) {
  const common = { width:size, height:size, viewBox:"0 0 24 24", fill:"none", stroke:"currentColor", strokeWidth:1.8, strokeLinecap:"round", strokeLinejoin:"round" };
  const p = {
    headphones:<><path d="M4 14v-2a8 8 0 0 1 16 0v2"/><path d="M4 14v4a2 2 0 0 0 2 2h1v-7H6a2 2 0 0 0-2 2Z"/><path d="M20 14v4a2 2 0 0 1-2 2h-1v-7h1a2 2 0 0 1 2 2Z"/></>,
    edit:<><path d="M12 20H4a1 1 0 0 1-1-1v-8"/><path d="M15.5 5.5 18.5 8.5"/><path d="m13 18 7.5-7.5a2.1 2.1 0 0 0-3-3L10 15v3h3Z"/><path d="M7 3h6"/><path d="M7 7h4"/></>,
    music:<><path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/></>,
    person:<><circle cx="12" cy="7" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>,
    gear:<><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-1.7 1.7-.06-.06a1.7 1.7 0 0 0-1.88-.34 1.7 1.7 0 0 0-1.03 1.56V20h-2.4v-.2a1.7 1.7 0 0 0-1.03-1.56 1.7 1.7 0 0 0-1.88.34l-.06.06-1.7-1.7.06-.06A1.7 1.7 0 0 0 8.46 15 1.7 1.7 0 0 0 6.9 14H6.7v-2.4h.2a1.7 1.7 0 0 0 1.56-1.03 1.7 1.7 0 0 0-.34-1.88l-.06-.06 1.7-1.7.06.06a1.7 1.7 0 0 0 1.88.34A1.7 1.7 0 0 0 12.73 5.8V5h2.4v.2a1.7 1.7 0 0 0 1.03 1.56 1.7 1.7 0 0 0 1.88-.34l.06-.06 1.7 1.7-.06.06a1.7 1.7 0 0 0-.34 1.88A1.7 1.7 0 0 0 20.96 11h.2v2.4h-.2A1.7 1.7 0 0 0 19.4 15Z"/></>,
    send:<><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></>,
    mail:<><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></>,
    arrow:<><path d="M5 19 19 5"/><path d="M8 5h11v11"/></>,
    play:<path d="m9 6 10 6-10 6V6Z" fill="currentColor" stroke="none"/>,
    pause:<><path d="M8 6v12"/><path d="M16 6v12"/></>,
    trash:<><path d="M4 7h16"/><path d="M10 11v6M14 11v6"/><path d="M9 7V4h6v3"/><path d="M6 7l1 14h10l1-14"/></>,
  };
  return <svg {...common}>{p[name]}</svg>;
}

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE, { keyPath:"id" });
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function getSongs() {
  const db = await openDB();
  return new Promise((resolve,reject) => {
    const req = db.transaction(STORE,"readonly").objectStore(STORE).getAll();
    req.onsuccess = () => resolve(req.result.sort((a,b)=>b.createdAt-a.createdAt));
    req.onerror = () => reject(req.error);
  });
}
async function putSong(song) {
  const db = await openDB();
  return new Promise((resolve,reject) => {
    const req = db.transaction(STORE,"readwrite").objectStore(STORE).put(song);
    req.onsuccess = resolve; req.onerror = () => reject(req.error);
  });
}
async function removeSong(id) {
  const db = await openDB();
  return new Promise((resolve,reject) => {
    const req = db.transaction(STORE,"readwrite").objectStore(STORE).delete(id);
    req.onsuccess = resolve; req.onerror = () => reject(req.error);
  });
}

function App() {
  const [active,setActive] = useState("demos");
  const [songs,setSongs] = useState([]);
  const [playing,setPlaying] = useState(null);
  const [admin,setAdmin] = useState(false);
  const [modal,setModal] = useState(null);
  const [notice,setNotice] = useState("");
  const audio = useRef(null);

  useEffect(()=>{ getSongs().then(setSongs).catch(()=>{}); },[]);
  useEffect(()=>()=>{ if(audio.current) audio.current.pause(); },[]);

  const play = (song) => {
    if(playing === song.id){ audio.current?.pause(); setPlaying(null); return; }
    if(audio.current) audio.current.pause();
    const a = new Audio(URL.createObjectURL(song.file));
    audio.current = a;
    a.onended=()=>setPlaying(null);
    a.play();
    setPlaying(song.id);
  };

  const addSong = async (file,title) => {
    const song = { id:crypto.randomUUID(), title, file, createdAt:Date.now() };
    await putSong(song);
    setSongs(await getSongs());
    setNotice("Το MP3 προστέθηκε επιτυχώς.");
    setTimeout(()=>setNotice(""),2200);
  };

  const deleteSong = async id => {
    await removeSong(id);
    if(playing===id){audio.current?.pause();setPlaying(null);}
    setSongs(await getSongs());
  };

  return <div className="app-shell">
    <header className="hero">
      <div className="hero-image"/><div className="hero-overlay"/>
      <button className="manage" onClick={()=>setModal(admin?"admin":"login")}><Icon name="gear" size={27}/>{admin?"Πίνακας":"Διαχείριση"}</button>
      <div className="identity">
        <div className="eyebrow">ANDREAS</div><h1>HADJIPANAYIOTOU</h1>
        <div className="roles">Lyricist <b>•</b> Songwriter <b>•</b> Creator</div>
        <div className="signature">Ανδρέας Χατζηπαναγιώτου<span/></div>
      </div>
    </header>

    <nav className="tabs">
      {tabs.map(t=><button key={t.id} className={active===t.id?"tab active":"tab"} onClick={()=>setActive(t.id)}>
        <Icon name={t.icon} size={30}/><span>{t.label}</span>
      </button>)}
    </nav>

    <main>
      {active==="demos" && <section className="content-section">
        <div className="section-title"><span className="section-icon"><Icon name="headphones" size={38}/></span><div><h2>Demos</h2><p>Ακούστε τα διαθέσιμα demos. Για ενδιαφέρον, πατήστε «Ενδιαφέρομαι».</p></div></div>
        {songs.length===0 ? <div className="empty"><Icon name="headphones" size={44}/><strong>Δεν υπάρχουν demos ακόμη.</strong><span>Μπες στη «Διαχείριση» για να προσθέσεις MP3 απευθείας από το κινητό.</span></div> :
          songs.map(s=><DemoCard key={s.id} song={s} playing={playing===s.id} onPlay={()=>play(s)} onInterest={()=>setModal("interest")}/>)}
      </section>}
      {active==="lyrics" && <InfoSection title="Στίχοι" icon="edit" text="Επιλεγμένα lyric concepts, hooks και ολοκληρωμένα τραγούδια." cards={["Θεσσαλονίκη — concept","Νυχτερινή διαδρομή — hook","Μια τελευταία φορά — ballad"]}/>}
      {active==="releases" && <InfoSection title="Κυκλοφορίες" icon="music" text="Οι διαθέσιμες κυκλοφορίες και συνεργασίες του δημιουργού." cards={["Νέα κυκλοφορία","Single / Collaboration","Coming soon"]}/>}
      {active==="bio" && <InfoSection title="Βιογραφικό" icon="person" text="Ανδρέας Χατζηπαναγιώτου — Lyricist · Songwriter · Creator." cards={["Lyricist","Songwriter","Creator"]}/>}
    </main>

    <form className="message-bar" onSubmit={e=>{e.preventDefault();setNotice("Το μήνυμά σου στάλθηκε.");setTimeout(()=>setNotice(""),2200)}}>
      <span className="bubble">•••</span><input placeholder="Γράψε το μήνυμά σου..."/><button><Icon name="send" size={23}/></button>
    </form>
    {notice && <div className="toast">{notice}</div>}
    {modal==="login" && <Login onSuccess={()=>{setAdmin(true);setModal("admin")}} close={()=>setModal(null)}/>}
    {modal==="admin" && <Admin songs={songs} addSong={addSong} deleteSong={deleteSong} logout={()=>{setAdmin(false);setModal(null)}} close={()=>setModal(null)}/>}
    {modal==="interest" && <Interest close={()=>setModal(null)} onDone={()=>{setModal(null);setNotice("Το ενδιαφέρον σου καταχωρήθηκε.");setTimeout(()=>setNotice(""),2200)}}/>}
  </div>;
}

function DemoCard({song,playing,onPlay,onInterest}){
  return <article className="demo-card">
    <div className="demo-head"><h3>{song.title}</h3><span>Demo</span></div>
    <div className="player">
      <button className="play-btn" onClick={onPlay}><Icon name={playing?"pause":"play"} size={29}/></button>
      <span className="time">{playing?"Αναπαραγωγή":"0:00"}</span>
      <div className="seek"><span style={{width:playing?"35%":"0%"}}/></div>
      <span className="mp3">MP3</span>
    </div>
    <div className="demo-actions"><button className="secondary"><Icon name="arrow" size={24}/> Άνοιγμα ήχου</button><button className="primary" onClick={onInterest}><Icon name="mail" size={23}/> Ενδιαφέρομαι</button></div>
  </article>;
}

function Login({onSuccess,close}){
  const [pin,setPin]=useState("");
  const submit=e=>{e.preventDefault(); if(pin===ADMIN_PIN) onSuccess(); else setPin("");};
  return <div className="modal-backdrop"><form className="modal" onSubmit={submit}><button type="button" className="close" onClick={close}>×</button><h3>Διαχείριση</h3><p>Βάλε τον προσωπικό κωδικό διαχείρισης.</p><input className="big-input" autoFocus type="password" inputMode="numeric" value={pin} onChange={e=>setPin(e.target.value)} placeholder="Κωδικός"/><button className="primary full">Είσοδος</button></form></div>;
}

function Admin({songs,addSong,deleteSong,logout,close}){
  const [title,setTitle]=useState("");
  const [file,setFile]=useState(null);
  const [busy,setBusy]=useState(false);
  const submit=async e=>{e.preventDefault();if(!file||!title)return;setBusy(true);await addSong(file,title);setTitle("");setFile(null);e.target.reset();setBusy(false)};
  return <div className="modal-backdrop"><div className="modal admin-modal"><button className="close" onClick={close}>×</button><h3>Πίνακας διαχείρισης</h3><p>Πρόσθεσε MP3 απευθείας από το κινητό σου.</p>
    <form onSubmit={submit}>
      <label>Τίτλος τραγουδιού<input required value={title} onChange={e=>setTitle(e.target.value)} placeholder="π.χ. Θεσσαλονίκη"/></label>
      <label className="file-label">MP3 αρχείο<input required type="file" accept="audio/mpeg,.mp3,audio/*" onChange={e=>setFile(e.target.files?.[0]||null)}/></label>
      <button className="primary full" disabled={busy}>{busy?"Αποθήκευση…":"＋ Προσθήκη MP3"}</button>
    </form>
    <div className="admin-list"><strong>Τα demos μου</strong>{songs.length===0?<small>Δεν έχεις προσθέσει τραγούδια.</small>:songs.map(s=><div className="admin-row" key={s.id}><span>{s.title}<small>{(s.file.size/1024/1024).toFixed(1)} MB</small></span><button onClick={()=>deleteSong(s.id)}><Icon name="trash" size={20}/></button></div>)}</div>
    <button className="secondary full" onClick={logout}>Έξοδος</button>
    <small className="storage-note">Τα MP3 αποθηκεύονται σε αυτόν τον browser/κινητό. Δεν ανεβαίνουν σε GitHub.</small>
  </div>;
}

function Interest({close,onDone}){
  return <div className="modal-backdrop"><form className="modal" onSubmit={e=>{e.preventDefault();onDone()}}><button type="button" className="close" onClick={close}>×</button><h3>Ενδιαφέρομαι</h3><label>Όνομα<input required placeholder="Το όνομά σου"/></label><label>Email<input required type="email" placeholder="email@example.com"/></label><label>Μήνυμα<textarea rows="3" placeholder="Πες μου για ποιο demo ενδιαφέρεσαι..."/></label><button className="primary full"><Icon name="mail" size={21}/> Αποστολή ενδιαφέροντος</button></form></div>;
}

function InfoSection({title,icon,text,cards}){return <section className="content-section"><div className="section-title"><span className="section-icon"><Icon name={icon} size={38}/></span><div><h2>{title}</h2><p>{text}</p></div></div><div className="info-grid">{cards.map((c,i)=><div className="info-card" key={i}><span>0{i+1}</span><strong>{c}</strong><small>Περισσότερες πληροφορίες σύντομα</small></div>)}</div></section>}

createRoot(document.getElementById("root")).render(<App/>);
